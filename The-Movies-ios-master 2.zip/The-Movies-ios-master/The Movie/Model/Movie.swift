//
//  Movie.swift
//  The Movie
//
//  Created by Win Than Htike on 8/2/17.
//  Copyright © 2017 Win Than Htike. All rights reserved.
//

import Foundation

class Movie {
    
    var title : String = ""
    var poster_path : String = ""
    var overview : String = ""
    
    init() {}
    
}
