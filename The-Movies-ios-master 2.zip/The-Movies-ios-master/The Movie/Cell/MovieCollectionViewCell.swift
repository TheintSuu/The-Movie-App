//
//  MovieCollectionViewCell.swift
//  The Movie
//
//  Created by Win Than Htike on 8/4/17.
//  Copyright © 2017 Win Than Htike. All rights reserved.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var movieImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

}
